import { AlertTriangle, ArrowUpRight, BrainCircuit } from "lucide-react";

export default function BottleneckAlert() {
  return (
    <div className="alert-card card">
      <div className="section-head"><div><span className="eyebrow">PREDICTIVE ALERT</span><h2>Next bottleneck</h2></div><AlertTriangle className="warn"/></div>
      <div className="alert-dept"><div className="dept-orb">ER</div><div><strong>Emergency</strong><span>Predicted congestion in ~24 min</span></div><em>HIGH</em></div>
      <div className="alert-grid">
        <div><span>Current queue</span><strong>12</strong></div>
        <div><span>Predicted</span><strong>19</strong></div>
        <div><span>Confidence</span><strong>91%</strong></div>
      </div>
      <div className="explain"><BrainCircuit size={16}/><span>Why: arrivals +22% · staff availability −12% · service time +9%</span></div>
      <button className="outline-btn"><ArrowUpRight size={15}/> Open AI analysis</button>
    </div>
  );
}
