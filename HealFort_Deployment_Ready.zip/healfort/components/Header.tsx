 "use client";

import { Bell, Search, ShieldCheck } from "lucide-react";

export default function Header({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <header className="topbar">
      <div>
        <div className="eyebrow">HEALFORT / OPERATIONS</div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      <div className="top-actions">
        <div className="system-status"><span className="pulse-dot" /> Systems nominal</div>
        <button className="icon-btn"><Search size={18}/></button>
        <button className="icon-btn"><Bell size={18}/><b>3</b></button>
        <div className="profile-chip"><ShieldCheck size={17}/><span>Verified staff</span></div>
      </div>
    </header>
  );
}
