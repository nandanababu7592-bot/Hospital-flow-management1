import { departments } from "@/data/departments";

export default function HospitalMap() {
  return (
    <div className="card map-card">
      <div className="section-head"><div><span className="eyebrow">DIGITAL TWIN</span><h2>Hospital Flow Map</h2></div><span className="legend"><i/> occupancy</span></div>
      <div className="hospital-map">
        <div className="map-corridor"/>
        <div className="map-room room-er"><b>ER</b><span>82%</span></div>
        <div className="map-room room-icu"><b>ICU</b><span>71%</span></div>
        <div className="map-room room-rad"><b>RADIOLOGY</b><span>76%</span></div>
        <div className="map-room room-opd"><b>OPD</b><span>63%</span></div>
        <div className="map-room room-dx"><b>DIAGNOSTICS</b><span>79%</span></div>
        <div className="map-room room-rx"><b>PHARMACY</b><span>58%</span></div>
        <div className="map-dot d1"/><div className="map-dot d2"/><div className="map-dot d3"/>
      </div>
      <div className="map-foot"><span>Live simulated occupancy</span><span>Last update: just now</span></div>
    </div>
  );
}
