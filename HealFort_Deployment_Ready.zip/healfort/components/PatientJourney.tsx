const steps = ["Registration", "Triage", "Emergency", "Doctor", "Diagnostics", "Treatment", "Discharge"];

export default function PatientJourney() {
  return (
    <div className="card journey-card">
      <div className="section-head"><div><span className="eyebrow">PATIENT JOURNEY</span><h2>HF-2041</h2></div><span className="priority high">HIGH</span></div>
      <div className="journey">{steps.map((step, i) => <div className={i === 4 ? "journey-step active" : "journey-step"} key={step}><div className="journey-node">{i < 4 ? "✓" : i + 1}</div><span>{step}</span>{i < steps.length-1 && <i/>}</div>)}</div>
      <div className="journey-warning"><b>Potential delay:</b> Diagnostics queue is currently 11 patients.</div>
    </div>
  );
}
