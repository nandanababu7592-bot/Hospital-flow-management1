 "use client";

import { useState } from "react";
import { FlaskConical, Minus, Plus, RotateCcw, Sparkles } from "lucide-react";

export default function SimulationPanel() {
  const [doctors, setDoctors] = useState(4);
  const [beds, setBeds] = useState(12);
  const [arrival, setArrival] = useState(100);
  const wait = Math.max(12, 31 - (doctors - 4) * 7 - (beds - 12) * 0.5 + (arrival - 100) * 0.12);
  const queue = Math.max(4, Math.round(18 - (doctors - 4) * 5 - (beds - 12) * 0.3 + (arrival - 100) * 0.08));
  return (
    <div className="simulation-shell">
      <div className="sim-control card"><div className="section-head"><div><span className="eyebrow">SCENARIO BUILDER</span><h2>What-If Simulation</h2></div><FlaskConical/></div>
        <Control label="Emergency doctors" value={doctors} setValue={setDoctors} min={2} max={8}/>
        <Control label="Available beds" value={beds} setValue={setBeds} min={4} max={30}/>
        <Control label="Patient arrivals index" value={arrival} setValue={setArrival} min={70} max={140} suffix="%"/>
        <button className="reset-btn" onClick={() => {setDoctors(4);setBeds(12);setArrival(100)}}><RotateCcw size={15}/> Reset scenario</button>
      </div>
      <div className="sim-result card"><span className="eyebrow">PROJECTED OUTCOME</span><h2>Scenario impact</h2>
        <div className="result-grid"><Metric label="Waiting time" value={`${Math.round(wait)} min`} base="31 min"/><Metric label="Queue size" value={`${queue}`} base="18"/><Metric label="Bed pressure" value={beds < 10 ? "High" : "Moderate"} base="Current"/></div>
        <div className="sim-ai"><Sparkles size={18}/><div><strong>AI interpretation</strong><p>{doctors > 4 ? "Additional staffing materially reduces projected Emergency waiting time." : "Try adding one doctor or increasing available beds to test a lower-congestion scenario."}</p></div></div>
      </div>
    </div>
  );
}
function Control({label,value,setValue,min,max,suffix=""}:{label:string;value:number;setValue:(v:number)=>void;min:number;max:number;suffix?:string}) {
  return <div className="control"><div><span>{label}</span><b>{value}{suffix}</b></div><div className="stepper"><button onClick={()=>setValue(Math.max(min,value-1))}><Minus size={14}/></button><div className="slider"><i style={{width:`${((value-min)/(max-min))*100}%`}}/></div><button onClick={()=>setValue(Math.min(max,value+1))}><Plus size={14}/></button></div></div>
}
function Metric({label,value,base}:{label:string;value:string;base:string}) { return <div className="metric"><span>{label}</span><strong>{value}</strong><small>Baseline {base}</small></div> }
