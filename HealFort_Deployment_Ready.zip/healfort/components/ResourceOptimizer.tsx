import { ArrowRight, UsersRound } from "lucide-react";

export default function ResourceOptimizer() {
  return (
    <div className="card resource-card">
      <div className="section-head"><div><span className="eyebrow">RESOURCE OPTIMIZER</span><h2>Suggested allocation</h2></div><UsersRound/></div>
      <div className="move-box"><div><strong>Outpatient</strong><span>7 doctors · 63% load</span></div><ArrowRight/><div><strong>Emergency</strong><span>4 doctors · 91% load</span></div></div>
      <div className="impact"><div><span>Projected wait</span><b>31 → 21 min</b></div><div><span>Queue</span><b>18 → 11</b></div></div>
      <button className="outline-btn">Review allocation</button>
    </div>
  );
}
