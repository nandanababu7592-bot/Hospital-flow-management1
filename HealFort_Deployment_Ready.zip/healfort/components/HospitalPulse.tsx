export default function HospitalPulse() {
  return (
    <div className="pulse-card card">
      <div className="section-head"><div><span className="eyebrow">LIVE INTELLIGENCE</span><h2>Hospital Pulse</h2></div><span className="live-tag">LIVE</span></div>
      <div className="pulse-main">
        <div className="score-ring"><strong>82</strong><span>/100</span></div>
        <div><h3>Flow is stable with emerging pressure</h3><p>Emergency and diagnostics are approaching capacity. AI forecasts elevated queue pressure within 30 minutes.</p></div>
      </div>
      <div className="score-bars">
        {[
          ["Patient flow", 84], ["Resources", 76], ["Bed capacity", 81], ["Staff load", 68]
        ].map(([name, val]) => <div className="bar-row" key={name}><span>{name}</span><div><i style={{width:`${val}%`}} /></div><b>{val}</b></div>)}
      </div>
    </div>
  );
}
