 "use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Activity, BrainCircuit, Building2, BedDouble, Siren, Users, Boxes, FlaskConical, LogOut } from "lucide-react";
import Logo from "./Logo";

const items = [
  ["/dashboard", "Command Center", Activity],
  ["/patients", "Patient Flow", Users],
  ["/departments", "Departments", Building2],
  ["/resources", "Resources", Boxes],
  ["/simulation", "Simulation Lab", FlaskConical],
  ["/emergency", "Surge Mode", Siren],
  ["/ai", "AI Insights", BrainCircuit],
] as const;

export default function Sidebar() {
  const pathname = usePathname();
  return (
    <aside className="sidebar">
      <Logo />
      <nav>
        {items.map(([href, label, Icon]) => (
          <Link key={href} href={href} className={pathname === href ? "nav-item active" : "nav-item"}>
            <Icon size={18} />
            <span>{label}</span>
          </Link>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <div className="secure-mini"><BedDouble size={16}/><span>Secure staff session</span><i /></div>
        <Link href="/" className="nav-item"><LogOut size={18}/><span>Sign out</span></Link>
      </div>
    </aside>
  );
}
