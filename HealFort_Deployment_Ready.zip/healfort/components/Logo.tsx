export default function Logo() {
  return (
    <div className="brand">
      <div className="brand-mark">
        <span className="brand-cross">+</span>
      </div>
      <div>
        <strong>HEALFORT</strong>
        <small>AI HOSPITAL FLOW</small>
      </div>
    </div>
  );
}
