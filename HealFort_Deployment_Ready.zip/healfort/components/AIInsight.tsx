import { BrainCircuit, CheckCircle2, ChevronRight } from "lucide-react";

export default function AIInsight() {
  return (
    <div className="card ai-card">
      <div className="section-head"><div><span className="eyebrow">EXPLAINABLE AI</span><h2>Recommendation</h2></div><BrainCircuit/></div>
      <h3>Consider reallocating 1 available doctor to Emergency.</h3>
      <p>Simulation estimates a reduction in Emergency waiting time from <b>31 → 21 min</b> while maintaining acceptable Outpatient load.</p>
      <div className="factor-list">
        <div><CheckCircle2/><span>Emergency arrivals rising</span><b>+22%</b></div>
        <div><CheckCircle2/><span>Outpatient capacity available</span><b>+18%</b></div>
        <div><CheckCircle2/><span>Projected queue reduction</span><b>−7</b></div>
      </div>
      <button className="primary-btn">Run simulation <ChevronRight size={16}/></button>
    </div>
  );
}
