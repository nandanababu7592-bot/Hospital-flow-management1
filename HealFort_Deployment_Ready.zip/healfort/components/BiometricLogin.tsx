 "use client";

import { useEffect, useRef, useState } from "react";
import { Camera, CheckCircle2, Fingerprint, LockKeyhole, ShieldCheck, UserRound, XCircle } from "lucide-react";

const MODEL_URL = "https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/model";

type FaceApi = typeof import("@vladmandic/face-api");

export default function BiometricLogin() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [faceapi, setFaceapi] = useState<FaceApi | null>(null);
  const [status, setStatus] = useState<"idle"|"loading"|"ready"|"scanning"|"matched"|"failed">("idle");
  const [message, setMessage] = useState("Use the enrolled demo staff profile to unlock.");
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [descriptor, setDescriptor] = useState<Float32Array | null>(null);

  useEffect(() => {
    let mounted = true;
    import("@vladmandic/face-api").then(async (api) => {
      if (!mounted) return;
      setFaceapi(api);
      setStatus("loading");
      await Promise.all([
        api.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        api.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
        api.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      ]);
      const img = await loadImage("/staff/demo-face.jpg");
      const ref = await api.detectSingleFace(img, new api.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }))
        .withFaceLandmarks()
        .withFaceDescriptor();
      if (!ref) {
        setStatus("failed");
        setMessage("The enrolled demo face could not be detected. Use a clearer front-facing image.");
        return;
      }
      setDescriptor(ref.descriptor);
      setStatus("ready");
      setMessage("Camera verification is ready.");
    }).catch(() => {
      setStatus("failed");
      setMessage("Face recognition models could not be loaded. Check your internet connection.");
    });
    return () => { mounted = false; };
  }, []);

  async function startCamera() {
    if (!faceapi || !descriptor || !videoRef.current) return;
    try {
      const media = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: 720, height: 540 }, audio: false });
      setStream(media);
      videoRef.current.srcObject = media;
      await videoRef.current.play();
      setStatus("scanning");
      setMessage("Looking for the enrolled demo face...");
      scan(apiSafe(faceapi), descriptor);
    } catch {
      setStatus("failed");
      setMessage("Camera permission was not granted. Use Hospital ID / PIN fallback.");
    }
  }

  async function scan(api: FaceApi, ref: Float32Array) {
    if (!videoRef.current || status === "matched") return;
    const result = await api.detectSingleFace(videoRef.current, new api.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }))
      .withFaceLandmarks()
      .withFaceDescriptor();
    if (result) {
      const distance = api.euclideanDistance(ref, result.descriptor);
      if (distance < 0.50) {
        setStatus("matched");
        setMessage(`Identity verified · match distance ${distance.toFixed(2)}`);
        stream?.getTracks().forEach(t => t.stop());
        setTimeout(() => window.location.href = "/dashboard", 900);
        return;
      }
      setMessage("Face detected, but it does not match the enrolled demo profile.");
    }
    if (status !== "matched") window.setTimeout(() => scan(api, ref), 500);
  }

  function fallback() {
    window.location.href = "/dashboard";
  }

  return (
    <div className="login-wrap">
      <div className="login-glow"/>
      <div className="login-card">
        <div className="login-brand"><div className="brand-mark large"><span className="brand-cross">+</span></div><div><strong>HEALFORT</strong><small>AI HOSPITAL FLOW</small></div></div>
        <div className="login-title"><span className="eyebrow">SECURE STAFF ACCESS</span><h1>Welcome back.</h1><p>Verify your identity to enter the hospital command center.</p></div>

        <div className="face-panel">
          <div className="camera-frame">
            <video ref={videoRef} muted playsInline className="camera-video"/>
            {!stream && <div className="camera-placeholder"><Camera size={30}/><span>{status === "loading" ? "Loading recognition models..." : "Camera ready"}</span></div>}
            {status === "scanning" && <div className="scan-line"/>}
            {status === "matched" && <div className="match-overlay"><CheckCircle2 size={44}/><strong>Identity verified</strong></div>}
          </div>
          <div className="face-info"><div className="avatar"><UserRound size={20}/></div><div><strong>Demo Staff Profile</strong><span>Operations / Emergency</span></div><ShieldCheck className="verified"/></div>
          <div className={`scan-status ${status}`}><span className="status-dot"/>{message}</div>
        </div>

        <button className="primary-btn wide" disabled={status === "loading" || status === "matched"} onClick={startCamera}>
          <Camera size={17}/> {status === "scanning" ? "Scanning..." : "Start face verification"}
        </button>
        <div className="or"><span>OR</span></div>
        <button className="outline-btn wide" onClick={fallback}><LockKeyhole size={16}/> Hospital ID + PIN</button>
        <div className="privacy-note"><Fingerprint size={15}/><span>Prototype biometric processing runs in the browser. No raw camera stream is uploaded by this demo.</span></div>
        <div className="demo-label">DEMO / SYNTHETIC HOSPITAL DATA</div>
      </div>
    </div>
  );
}
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}
function apiSafe(api: FaceApi) { return api; }
