import { ReactNode } from "react";

export default function KPICard({ label, value, delta, icon, tone = "blue" }: {
  label: string; value: string; delta: string; icon: ReactNode; tone?: string;
}) {
  return (
    <div className="kpi card">
      <div className={`kpi-icon ${tone}`}>{icon}</div>
      <div className="kpi-copy"><span>{label}</span><strong>{value}</strong><small>{delta}</small></div>
    </div>
  );
}
