import AppShell from "@/components/AppShell";
import Header from "@/components/Header";
import { Siren } from "lucide-react";

export default function Page() {
  return <AppShell><Header title="Emergency Surge Mode" subtitle="A dedicated command view for sudden patient-volume changes."/>
<div className="surge-banner"><div className="surge-icon"><Siren/></div><div><span className="eyebrow">SURGE DETECTION</span><h2>Emergency pressure is elevated</h2><p>Incoming patient volume is 38% above the current baseline.</p></div><span className="danger-badge">HIGH LOAD</span></div>
<div className="two-col"><div className="card action-plan"><span className="eyebrow">AI ACTION PLAN</span><h2>Recommended response</h2>{["Open additional treatment capacity","Allocate 1 available doctor","Reserve 3 beds for incoming cases","Notify operations coordinator"].map((x,i)=><div className="action-row" key={x}><b>0{i+1}</b><span>{x}</span><button>Review</button></div>)}</div><div className="card"><span className="eyebrow">SURGE METRICS</span><h2>Live pressure</h2><div className="big-metric"><strong>+38%</strong><span>arrival rate</span></div><div className="score-bars"><div className="bar-row"><span>ER capacity</span><div><i style={{width:"94%"}}/></div><b>94%</b></div><div className="bar-row"><span>Staff load</span><div><i style={{width:"91%"}}/></div><b>91%</b></div></div></div></div>
</AppShell>;
}
