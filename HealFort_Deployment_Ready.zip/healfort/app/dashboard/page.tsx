import AppShell from "@/components/AppShell";
import Header from "@/components/Header";
import KPICard from "@/components/KPICard";
import HospitalPulse from "@/components/HospitalPulse";
import BottleneckAlert from "@/components/BottleneckAlert";
import HospitalMap from "@/components/HospitalMap";
import AIInsight from "@/components/AIInsight";
import PatientJourney from "@/components/PatientJourney";
import ResourceOptimizer from "@/components/ResourceOptimizer";
import { Users, Clock3, BedDouble, AlertTriangle } from "lucide-react";

export default function Page() {
  return <AppShell><Header title="Command Center" subtitle="A live operational view of hospital flow, pressure points and AI recommendations."/>
<div className="page-grid">
  <div className="kpi-grid">
    <KPICard label="Patients in flow" value="124" delta="+8% vs 30 min" icon={<Users size={18}/>} />
    <KPICard label="Average wait" value="24 min" delta="−6 min after interventions" icon={<Clock3 size={18}/>} tone="green" />
    <KPICard label="Bed occupancy" value="76%" delta="+4% in the last hour" icon={<BedDouble size={18}/>} tone="purple" />
    <KPICard label="Active alerts" value="03" delta="1 high priority" icon={<AlertTriangle size={18}/>} tone="red" />
  </div>
  <div className="two-col"><HospitalPulse/><BottleneckAlert/></div>
  <div className="two-col"><HospitalMap/><AIInsight/></div>
  <div className="two-col"><PatientJourney/><ResourceOptimizer/></div>
</div>
</AppShell>;
}
