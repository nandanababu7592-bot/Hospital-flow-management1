import AppShell from "@/components/AppShell";
import Header from "@/components/Header";
import { departments } from "@/data/departments";

export default function Page() {
  return <AppShell><Header title="Departments" subtitle="Monitor capacity, queue pressure and staffing across the hospital."/>
<div className="department-grid">
{departments.map(d => <div className="card department-card" key={d.name}><div className="dept-top"><div className="dept-orb" style={{background:d.color}}>{d.short}</div><span className={`status-dot-label ${d.status.toLowerCase().replace(" ","-")}`}>{d.status}</span></div><h2>{d.name}</h2><div className="capacity"><div><span>Occupancy</span><b>{d.occupancy}%</b></div><div className="capacity-bar"><i style={{width:`${d.occupancy}%`,background:d.color}}/></div><div className="dept-stats"><div><span>Queue</span><b>{d.queue}</b></div><div><span>Staff</span><b>{d.staff}</b></div></div></div>)}
</div>
</AppShell>;
}
