import AppShell from "@/components/AppShell";
import Header from "@/components/Header";
import ResourceOptimizer from "@/components/ResourceOptimizer";
import { resources } from "@/data/resources";
import { AlertTriangle } from "lucide-react";

export default function Page() {
  return <AppShell><Header title="Resources" subtitle="See availability and simulate smarter allocation before taking action."/>
<div className="resource-grid">{resources.map(r => <div className="card resource-stat" key={r.name}><span className="eyebrow">{r.unit.toUpperCase()}</span><h2>{r.name}</h2><strong>{r.available}<small> / {r.total}</small></strong><div className="capacity-bar"><i style={{width:`${(r.available/r.total)*100}%`}}/></div><span>{Math.round((r.available/r.total)*100)}% currently available</span></div>)}</div>
<div className="two-col"><ResourceOptimizer/><div className="card"><span className="eyebrow">FORECAST</span><h2>Bed availability</h2><div className="bed-forecast">{[["Now",23],["+30m",18],["+1h",12],["+2h",7]].map(([t,v])=><div key={t}><span>{t}</span><strong>{v}</strong><small>beds</small></div>)}</div><div className="explain"><AlertTriangle size={16}/><span>Potential bed pressure predicted in approximately 90 minutes.</span></div></div></div>
</AppShell>;
}
