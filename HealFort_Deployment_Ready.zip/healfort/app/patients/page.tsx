import AppShell from "@/components/AppShell";
import Header from "@/components/Header";
import PatientJourney from "@/components/PatientJourney";
import { patients } from "@/data/patients";

export default function Page() {
  return <AppShell><Header title="Patient Flow" subtitle="Follow patients across the hospital journey and identify where delays are forming."/>
<div className="card table-card">
  <div className="section-head"><div><span className="eyebrow">LIVE FLOW</span><h2>Patient journey queue</h2></div><span className="live-tag">SYNTHETIC DATA</span></div>
  <div className="table-wrap"><table><thead><tr><th>Patient</th><th>Department</th><th>Priority</th><th>Wait</th><th>Status</th></tr></thead><tbody>
  {patients.map(p => <tr key={p.id}><td><strong>{p.id}</strong><small>{p.name} · {p.age} yrs</small></td><td>{p.department}</td><td><span className={`priority ${p.priority.toLowerCase()}`}>{p.priority}</span></td><td>{p.wait} min</td><td><span className="status-pill">{p.status}</span></td></tr>)}
  </tbody></table></div>
</div>
<div className="two-col"><PatientJourney/><div className="card"><span className="eyebrow">FLOW FORECAST</span><h2>Queue trajectory</h2><div className="forecast"><div><span>Now</span><b>12</b></div><div><span>+30m</span><b>15</b></div><div className="danger"><span>+60m</span><b>19</b></div><div><span>+90m</span><b>14</b></div></div><p className="muted">AI expects a temporary Emergency surge followed by stabilization if resource allocation is maintained.</p></div></div>
</AppShell>;
}
