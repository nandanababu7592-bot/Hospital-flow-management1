import AppShell from "@/components/AppShell";
import Header from "@/components/Header";
import SimulationPanel from "@/components/SimulationPanel";

export default function Page() {
  return <AppShell><Header title="Simulation Lab" subtitle="Test operational interventions before applying them to the hospital."/><SimulationPanel/><div className="card compare-card"><span className="eyebrow">SCENARIO COMPARISON</span><h2>Intervention preview</h2><div className="compare-grid"><div><span>Baseline</span><strong>31 min</strong><small>18 waiting</small></div><div><span>+1 doctor</span><strong>24 min</strong><small>13 waiting</small></div><div className="highlight"><span>+2 doctors</span><strong>18 min</strong><small>8 waiting</small></div></div></div></AppShell>;
}
