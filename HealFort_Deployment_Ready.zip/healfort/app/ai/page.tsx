import AppShell from "@/components/AppShell";
import Header from "@/components/Header";
import AIInsight from "@/components/AIInsight";

export default function Page() {
  return <AppShell><Header title="AI Insights" subtitle="Explainable predictions, root-cause analysis and operational recommendations."/>
<div className="two-col"><AIInsight/><div className="card root-cause"><span className="eyebrow">ROOT-CAUSE ANALYSIS</span><h2>Why is Emergency slowing?</h2><p className="muted">The model groups recent operational signals into contributing factors.</p>{[["Patient arrivals",82,"+22%"],["Staff availability",67,"−12%"],["Service time",51,"+9%"],["Bed turnover",38,"−6%"]].map(([n,v,t])=><div className="cause" key={n}><div><span>{n}</span><b>{t}</b></div><div className="capacity-bar"><i style={{width:`${v}%`}}/></div></div>)}</div></div>
<div className="card timeline-card"><span className="eyebrow">DECISION TIMELINE</span><h2>What HealFort detected</h2><div className="timeline">{["10:05 — Patient surge detected","10:12 — Emergency queue rising","10:18 — Bottleneck predicted","10:19 — Recommendation generated","10:32 — Queue projected to stabilize"].map((x,i)=><div key={x}><i className={i===4?"done":""}/><span>{x}</span></div>)}</div></div>
</AppShell>;
}
