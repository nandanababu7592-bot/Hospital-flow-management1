import { Patient } from "@/types/hospital";

export const patients: Patient[] = [
  { id: "HF-2041", name: "Demo Patient 01", age: 46, department: "Emergency", priority: "High", wait: 18, status: "Waiting", arrival: "18:02" },
  { id: "HF-2038", name: "Demo Patient 02", age: 31, department: "Radiology", priority: "Medium", wait: 26, status: "Diagnostics", arrival: "17:54" },
  { id: "HF-2035", name: "Demo Patient 03", age: 68, department: "Emergency", priority: "Critical", wait: 7, status: "In consultation", arrival: "18:12" },
  { id: "HF-2031", name: "Demo Patient 04", age: 23, department: "OPD", priority: "Low", wait: 34, status: "Waiting", arrival: "17:47" },
  { id: "HF-2029", name: "Demo Patient 05", age: 54, department: "Diagnostics", priority: "High", wait: 22, status: "Diagnostics", arrival: "17:59" }
];
