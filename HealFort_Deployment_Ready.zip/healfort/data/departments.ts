import { Department } from "@/types/hospital";

export const departments: Department[] = [
  { name: "Emergency", short: "ER", occupancy: 82, queue: 12, staff: 4, status: "At Risk", color: "#ff6b6b" },
  { name: "Radiology", short: "RAD", occupancy: 76, queue: 9, staff: 3, status: "Busy", color: "#f4b942" },
  { name: "ICU", short: "ICU", occupancy: 71, queue: 2, staff: 8, status: "Stable", color: "#4cc9f0" },
  { name: "Outpatient", short: "OPD", occupancy: 63, queue: 7, staff: 7, status: "Stable", color: "#5dd39e" },
  { name: "Diagnostics", short: "DX", occupancy: 79, queue: 11, staff: 4, status: "Busy", color: "#b388ff" },
  { name: "Pharmacy", short: "RX", occupancy: 58, queue: 5, staff: 3, status: "Stable", color: "#66d9ef" }
];
