import { Resource } from "@/types/hospital";

export const resources: Resource[] = [
  { name: "Doctors", available: 18, total: 24, unit: "staff" },
  { name: "Nurses", available: 41, total: 52, unit: "staff" },
  { name: "Beds", available: 23, total: 96, unit: "beds" },
  { name: "Imaging", available: 3, total: 5, unit: "machines" },
  { name: "Ventilators", available: 11, total: 16, unit: "units" }
];
