export type PatientPriority = "Critical" | "High" | "Medium" | "Low";

export type Patient = {
  id: string;
  name: string;
  age: number;
  department: string;
  priority: PatientPriority;
  wait: number;
  status: "Waiting" | "In consultation" | "Diagnostics" | "Admitted";
  arrival: string;
};

export type Department = {
  name: string;
  short: string;
  occupancy: number;
  queue: number;
  staff: number;
  status: "Stable" | "Busy" | "At Risk" | "Critical";
  color: string;
};

export type Resource = {
  name: string;
  available: number;
  total: number;
  unit: string;
};
