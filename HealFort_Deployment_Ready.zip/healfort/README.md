# HealFort — AI Hospital Flow Prototype

Deployment-ready Next.js + TypeScript prototype.

## Included

- Secure staff access with a browser-local biometric demo
- Live webcam face comparison against `public/staff/demo-face.jpg`
- Command Center / Hospital Pulse
- Predictive bottleneck alert
- Explainable AI panel
- Digital hospital flow map
- Patient Flow
- Departments
- Resource optimizer
- Bed forecast
- What-If Simulation Lab
- Emergency Surge Mode
- AI Insights / root-cause view
- Synthetic demo hospital data
- Responsive UI
- Netlify configuration

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

Camera access normally requires HTTPS or localhost. Netlify provides HTTPS.

## Deploy to Netlify

1. Push this folder to GitHub.
2. Import the repository into Netlify.
3. Build command: `npm run build`
4. Netlify will use the included `netlify.toml`.
5. Open the deployed HTTPS URL and allow camera access.

## Biometric demo

The login uses `@vladmandic/face-api` in the browser. The demo loads the face-detection, landmark and recognition models from jsDelivr and computes the enrolled face descriptor from `public/staff/demo-face.jpg`. The live webcam frame is compared locally in the browser.

This is a hackathon prototype, not production-grade biometric authentication. It does not establish identity for a real hospital and should not be used as a real access-control system without security, privacy, liveness detection, consent, secure credential storage, audit controls and a proper identity provider.

The fallback "Hospital ID + PIN" button is intentionally included so the demo can continue if camera permission/model loading fails.

## Demo data

All patient, department, resource and AI values in this prototype are synthetic.
